CREATE TABLE Employee_Test
(Emp_ID INT Identity,-- starts with one increments by 1
Emp_name Varchar(100),Emp_Sal Decimal (10,2))
INSERT INTO Employee_Test VALUES ('Anees',1000);

INSERT INTO Employee_Test VALUES ('Rick',1200);

INSERT INTO Employee_Test VALUES ('John',1100);

INSERT INTO Employee_Test VALUES ('Stephen',1300);

INSERT INTO Employee_Test VALUES ('Maria',1400);

select * from Employee_Test
insert into emp(empno) values(2000)


CREATE TABLE Employee_Test_Audit

(

Emp_ID int,

Emp_name varchar(100),

Emp_Sal decimal (10,2),

Audit_Action varchar(100),

Audit_Timestamp datetime

)
select * from Employee_Test_Audit

CREATE trigger trgAfterinserted on employee_test
for insert
as

declare @empid int ;
declare @empname varchar(100);
declare @empsal decimal(10,2);
declare @audit_action varchar(100);
select @empid=i.emp_id from inserted i;
select @empname=i.emp_name from inserted i;
select @empsal=i.emp_sal from inserted i;

set @audit_action='inserted record--After insert trigger';

insert into employee_test_audit 
values(@empid,@empname,@empsal,@audit_action,getdate());
print 'after insert trigger fired' 

insert into Employee_Test values('ram',2000)
select * from Employee_Test
SELECT * FROM Employee_Test_Audit

alter trigger trgAfterdeleted on employee_test
for delete
as

declare @empid int ;
declare @empname varchar(100);
declare @empsal decimal(10,2);
declare @audit_action varchar(100);

select @empid=i.emp_id from deleted i;
select @empname=i.emp_name from deleted i;
select @empsal=i.emp_sal from deleted i;

set @audit_action='deleted record--After delete trigger';

insert into employee_test_audit 
values(@empid,@empname,@empsal,@audit_action,getdate());
print 'after delete trigger fired' 

delete from employee_test where Emp_ID=3
select * from employee_test
select * from Employee_Test_Audit

ALTER trigger trgInsteadofDelete on emp
instead of delete 
as
declare @empno int
declare @job varchar(100)
select @job=d.job from deleted d;
select @empno=d.empno from deleted d;
begin
if(@job ='PRESIDENT')
BEGIN
RAISERROR('cANNOT DELETE THIS PERSON WHO IS VVIP',16,1)
END
ELSE
BEGIN
DELETE FROM EMP WHERE EMPNO=@EMPNO 
PRINT 'RECORD DELETED -- INSTEAD OF DELETE TRIGGER.'
END
END


DELETE FROM EMP WHERE EMPNO=7839

SELECT * FROM EMP
