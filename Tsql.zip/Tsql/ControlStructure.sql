use akshay
--declaring the data type
--declare @name varchar(20),@age int
declare @name varchar(20)
declare @age int

DECLARE @count INT
DECLARE @sum INT
declare @branch varchar(10)

--assigning the value
set @name='John'
set @age=20
set @count=0
set @sum=0
set @branch='ece'
--display the value.select puts in result,print diplays in messages
select @name 
select @age

--if,else if and else
if @age<30
select 'beginner'
else if @age>40
select 'pro'
else
select 'experienced'

--while loop    
WHILE @count< 5
BEGIN
Set @sum=@sum+@count
SET @count = @count + 1;
END;
select 'The sum is ',@sum

--switch case
SELECT
CASE 
WHEN (@branch ='cs') THEN 'Computer science'
WHEN (@branch ='ece') THEN 'electronics'
WHEN (@branch ='mech') THEN 'mechanical'
ELSE 'Other'
END

SELECT 
CASE @branch
WHEN 'cs' THEN 'Computer science'
WHEN 'ece' THEN 'electronics'
WHEN 'mech' THEN 'mechanical'
ELSE 'Other'
END


SELECT LEFT(@name, 2)
SELECT LEN(@NAME)
SELECT CONCAT('Details : ' ,@NAME,' ',@age,' ',@branch)
Select lower(@name)

--Conversion function
declare @salary float
set @salary=123456.789
select cast(@salary as int)
select CONVERT(int,@salary)
select try_convert(datetime,'12/2/2000');
--select convert
--select * from emp