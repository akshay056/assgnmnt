use akshay
use akshay
declare @name varchar(20)
declare @age int

DECLARE @count INT
DECLARE @sum INT
declare @branch varchar(10)
declare @status varchar(20)
set @name='John'
set @age=20
set @branch='ece'
set @status='         i am single.              '


--select upper(@name)--select TRIM(@status)--SELECT REVERSE(@NAME)--SELECT RTRIM(@STATUS)--SELECT REPLACE(@NAME,'o','a')--select substring(@name,1,3)--SELECT LEN(@NAME)--Select lower(@name)

select @name as name,LEFT(@name, 2) as LEFTO,LEN(@NAME) AS SIZE,lower(@name) AS LOWERCASE,upper(@name) AS UPPERCASE,REVERSE(@NAME) AS REVERSED, REPLACE(@NAME,'o','a') AS ReplaceAinO,substring(@name,1,3) as substringofname

SELECT CONCAT('Details : ' ,@NAME,' ',@age,' ',@branch)

select @status as Statuss,ltrim(@status) as left_trim,TRIM(@status) as trimo,RTRIM(@STATUS) as right_trim

