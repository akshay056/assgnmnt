USE akshay
select * from emp

select * from dept
