begin try
insert into emp(empno,deptno) values(7839,10)
end
try
begin catch 
print @@error
print error_message()
end catch