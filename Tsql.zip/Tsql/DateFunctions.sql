use akshay
DECLARE @t  date
set @t=getdate()
  
SELECT DATENAME(year,@t) as _year
select getdate()as current_time_and_date
SELECT DATEPART(week,@t) _weekoftheyesr, DATEPART(weekday,@t) as dayofweek
select day(@t) as _day,month(@t) as _month,year(@t)as _year
select datediff(year,'6/5/2000',@t) as dste_diff
select dateadd(month,5,@t) as add_date