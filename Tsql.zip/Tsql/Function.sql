create function sumofnumbers(@a int,@b int)
returns int
as
begin
return @a+@b
end

select dbo.sumofnumbers(10,12) as sum

alter FUNCTION salarymore (@sal int)  
RETURNS TABLE  
AS  
RETURN  
    SELECT *  
    FROM emp  
    WHERE sal>@sal

select * from dbo.salarymore (2000)