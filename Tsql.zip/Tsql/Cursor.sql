declare empcursor cursor for select empno,ename,sal from emp order by sal desc
declare @name varchar(20),@sal int,@empno int
open empcursor
print @@fetch_status
fetch next from empcursor into @empno,@name,@sal
while @@FETCH_STATUS =0
begin
print @@fetch_status
print @name+'is earning ' +cast(@sal as varchar)
fetch next from empcursor into @empno,@name,@sal
end
close empcursor
print @@fetch_status
deallocate empcursor

--select ename+'is earning ' +cast(sal as varchar) from emp