create procedure GetEmpDetails
AS
begin 
select ename,job,sal
from emp
end;

execute GetEmpDetails

create procedure GETSPECIFICDETAILS @EMPNO INT
As 
begin
SELECT * FROM EMP
	WHERE @EMPNO=EMPNO
END


EXEC GETSPECIFICDETAILS @EMPNO = 7369
--
CREATE PROCEDURE GETDETAILS @EMPNO INT,@ENAME VARCHAR(20)

AS
BEGIN
SELECT * FROM EMP
	WHERE @EMPNO=EMPNO AND @ENAME=ENAME
END

exec GETDETAILS 7369,'smith'
exec GETDETAILS 7499,'allen'


CREATE PROCEDURE aDDDEPTN @DEPTNO INT,@DNAME CHAR(20),@LOC CHAR(20)
AS
BEGIN
INSERT INTO DEPT([DEPTNO],[DNAME],[LOC]) VALUES(@DEPTNO,@DNAME,@LOC)
END

EXEC aDDDEPTN 60,'MARKETING','MIAMI'

SELECT * FROM DEPT

CREATE PROCEDURE DELETEDEPT @DEPTNO INT
AS
BEGIN
DELETE FROM DEPT WHERE DEPTNO=@DEPTNO
END

EXEC DELETEDEPT 60

EXEC DELETEDEPT 50

CREATE PROCEDURE UPDATEDEPT @DEPTNO INT,@DNAME CHAR(20)
AS
BEGIN
UPDATE DEPT 
SET DNAME=@DNAME WHERE DEPTNO=@DEPTNO
END

EXEC UPDATEDEPT 10,'HR'

select * from emp

--hw
create procedure no_of_employees @deptno int
as
begin 
select  COUNT(*) from EMP where deptno=@deptno
end

exec no_of_employees 20

create procedure no_of_employees_of_job @job char(20)
as
begin 
select  COUNT(*) from EMP where job=@job
end
exec no_of_employees_of_job 'clerk'

create procedure employeeWithMaxSalary @deptno int
as
begin 
select * from EMP where sal=(select Max(sal) from EMP where deptno=@deptno)
end
exec employeeWithMaxSalary 30

ALTER procedure employeeDetails
as
begin
SELECT * FROM emp A 
      INNER JOIN dept B
        ON (A.deptno = B.deptno)
end
exec employeeDetails
